import javax.swing.*;
import java.awt.*;


public class Window extends JFrame {
	public Window() {
		setTitle("��� ���");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		
		Panel c0=new Panel(new GridLayout(6,1));
		
		Panel c1=new Panel(new FlowLayout(FlowLayout.LEFT,5,0));
		 
		c1.add(new JLabel("��            ��"));
		c1.add(new JTextField(8));
		c1.add(new JLabel("��            ��"));
		c1.add(new JTextField(3));
		
		Panel c2=new Panel(new FlowLayout(FlowLayout.LEFT,5,0));
		c2.add(new JLabel("�ֹε�Ϲ�ȣ"));
		c2.add(new JTextField(6));
		c2.add(new JLabel(" - "));
		c2.add(new JTextField(7));
		
		Panel c3=new Panel(new FlowLayout(FlowLayout.LEFT,5,0));
		c3.add(new JLabel("��            ��"));
		c3.add(new JTextField(22));
		
		Panel c4=new Panel(new FlowLayout(FlowLayout.LEFT,5,0));
		c4.add(new JLabel("��     ��     ��"));
		c4.add(new JTextField(8));
		
		Panel c5=new Panel(new FlowLayout(FlowLayout.LEFT,5,0));
		c5.add(new JLabel("��             ��"));
		c5.add(new JTextField(22));
		
		Panel c6=new Panel(new FlowLayout(FlowLayout.LEFT,5,0));
		c6.add(new Label("��    ��    ��   ��"));
		
		Panel c7=new Panel(new FlowLayout(FlowLayout.LEFT,5,0));
		c7.add(new TextArea());
		
		Panel c8=new Panel(new FlowLayout(FlowLayout.CENTER,5,0));
		c8.add(new Button("����"));
		c8.add(new Button("����"));
		
		c0.add(c1);
		c0.add(c2);
		c0.add(c3);
		c0.add(c4);
		c0.add(c5);
		c0.add(c6);
		
		add(c0,"North");
		add(c7,"Center");
		add(c8,"South");
		
		
		setBounds(9,22,350,420);
		setVisible(true);
	
	}
	
	public static void main(String[] args) {
		new Window();
	}
}
