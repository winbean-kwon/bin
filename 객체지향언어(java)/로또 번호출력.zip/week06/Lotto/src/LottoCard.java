import java.util.Scanner;

public class LottoCard {
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		
		int lottonumber[][]=new int[5][6];
		for(int i=0; i<5; i++) {
			for(int j=0; j<6; j++) {
				lottonumber[i][j]=scanner.nextInt();
				
				
			}
			
				
		}
		for(int i=0; i<5; i++) {
			for(int j=0; j<6; j++) {
				System.out.printf(lottonumber[i][j]+" ");
				
			}
			System.out.println(" ");
		}
	}
}
