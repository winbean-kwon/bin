
import java.util.Scanner;

public class Lotto {

	public static void main(String[] args) {
		
		Scanner scanner=new Scanner(System.in);
		
		int lottoNumber[]=new int[6];
		int repeat=5;
		for(int x=0; x<5; x++) {
			for(int i=0; i<lottoNumber.length; i++) {
			
				lottoNumber[i]=(int)(Math.random()*45)+1;
			
				for(int j=i-1; j>=0; j-- ) {//�ߺ�üũ
					if(lottoNumber[i]==lottoNumber[j]) {
						i--;
					break;
				}
			}
			
		}
			for(int a=0; a<lottoNumber.length; a++) {
				System.out.printf(lottoNumber[a] + " ");
			}
				
			System.out.println(" ");
		
		
		}

	}

}
